package pt.tecnico.blingbank.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlingbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
