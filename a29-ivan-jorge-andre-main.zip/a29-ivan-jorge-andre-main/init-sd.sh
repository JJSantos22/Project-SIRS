# Init script for the secure documents CLI

mvn install -pl Libraries -am
